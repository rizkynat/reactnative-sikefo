import * as React from 'react';
import { Text, View, StyleSheet, Image, ImageBackground, TouchableOpacity, CheckBox } from 'react-native';
import Constants from 'expo-constants';

// You can import from local files
import AssetExample from './components/AssetExample';

// or any pure javascript modules available in npm
import { IconButton, MD3Colors } from 'react-native-paper';

export default function App() {

  return (
    <View style={styles.main}>
     <View style={styles.bar_atas}>
      <Text style={styles.judul}>SIKEFO</Text>
      <Image source={require('./assets/account_profile_home.png')} style={styles.gambar_account} />
      <IconButton
        style={styles.icon_more}
        icon={require('./assets/more-icon.png')}
        iconColor={MD3Colors}
        size={20}
        onPress={() => console.log('Pressed')}
      />
     </View>
     <View style={styles.layout_banner}>
      <View style={styles.banner}>
        <ImageBackground source={require('./assets/bg-banner.png')} resizeMode="cover" style={styles.bg_banner}>
          <Text style={styles.txt_anda}>Anda</Text>
          <Text style={styles.txt_desc1}>tidak akan bisa lari </Text>
          <Text style={styles.txt_desc2}>dari tanggung jawab pada hari esok dengan menghindarinya pada hari ini !!</Text>
        </ImageBackground>
      </View>
     </View>
     <View style={styles.button}>
      <View style={styles.button_content}>
        <TouchableOpacity style = {styles.btn_kas}>
              <ImageBackground source={require('./assets/kas.png')} resizeMode="cover" style={styles.bg_button}>
                <Image source={require('./assets/kas-icon.png')} style = {styles.icon_kas}/>
                <Text style = {styles.txt_btn_kas}>
                  Kas
                </Text>
              </ImageBackground>
        </TouchableOpacity>
      </View>
      <View style={styles.button_content}>
        <TouchableOpacity style = {styles.btn_keuangan}>
            <ImageBackground source={require('./assets/keuangan.png')} resizeMode="cover" style={styles.bg_button}>
              <Image source={require('./assets/keuangan-icon.png')} style = {styles.icon_keuangan}/>
              <Text style = {styles.txt_btn_keuangan}>
                Keuangan
              </Text>
            </ImageBackground>
        </TouchableOpacity>
      </View>
     </View>
     <View style={styles.layout_tagihan}>
      <Text style = {styles.txt_tagihan}>Tagihan Kas</Text>
      <View style={styles.tagihan_content}>

      </View>
     </View>
     <View style={styles.layout_tagihan}>
      <Text style = {styles.txt_tagihan}>Riwayat Pembyaran</Text>
      <View style={styles.tagihan_content}>
          
      </View>
     </View>
    </View>
  );
}

const styles = StyleSheet.create({
  main: {
    backgroundColor: '#FFFFFF',
    
  },
  
  bar_atas: {
    height:43,
    width:404,
    flexDirection:'row',
    marginLeft:18,
    marginTop:54,
  },

  judul:{
    fontWeight:'bold',
    letterSpacing:0.155,
    fontSize:24
  },

  gambar_account:{
    width:40,
    height:43,
    marginLeft:222,
  },

  icon_more:{
    width:24,
    height:24,
    marginLeft:12
  },

  layout_banner:{
    justifyContent:'center',
  },

  banner:{
    width:407,
    height:196,
    marginLeft:9,
    marginTop:31
  },

  bg_banner:{
    width:393,
    height:196
  },

  txt_anda:{
    fontWeight:'bold',
    fontSize:20,
    color:'#FFFFFF',
    marginLeft:14,
    marginTop:7
  },

  txt_desc1:{
    width:239,
    textAlign:'left',
    fontSize:14,
    color:'#FFFFFF',
    marginLeft:14
  },

  txt_desc2:{
    width:239,
    textAlign:'left',
    fontSize:12,
    color:'#FFFFFF',
    marginLeft:14
  },

  button:{
    marginTop:35,
    flexDirection:'row',
    justifyContent:'center',

  },

  button_content:{
    flexDirection:'column',
    paddingRight:11,
    paddingLeft:11,
  },

  bg_button:{
    width:133,
    height:98,
  },

  btn_kas:{
    title: 'Kas',
    borderRadius:20,
  },

  txt_btn_kas:{
    marginTop:5,
    textAlign:'center',
    color:'#2B3467',
    fontWeight:'bold',
  },

  icon_kas:{
    marginTop:20,
    marginLeft:53,
  },
  
  btn_keuangan:{
    title: 'Kas',
    borderRadius:20,
  },

  txt_btn_keuangan:{
    marginTop:5,
    textAlign:'center',
    color:'#BAD7E9',
    fontWeight:'bold',
  },

  icon_keuangan:{
    marginTop:20,
    marginLeft:50,
  },

  layout_tagihan:{
    marginTop:35,
    marginLeft:14,
  },

  txt_tagihan:{
    fontWeight:'bold',
    fontSize:14,
  },

});
